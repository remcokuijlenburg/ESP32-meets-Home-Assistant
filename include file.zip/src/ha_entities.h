#pragma once

// ============================================================
// VERLICHTING
// ============================================================

#define HA_LIGHT_WOONKAMER_1  "light.k_o_o"
#define HA_LIGHT_WOONKAMER_2  "light.smartplug_remto"

#define HA_LIGHT_HAL_1        "light.lamp_hal"
#define HA_LIGHT_HAL_2        "light.lamp_voordeur"

#define HA_LIGHT_BIJKEUKEN    "light.signify_netherlanbijkeuken_lamp"

#define HA_LIGHT_TUINKANTOOR_1 "light.schuurlamp_fietsendeel"
#define HA_LIGHT_TUINKANTOOR_2 "light.philips_1"

#define HA_LIGHT_STEEG_1      "light.steeg_sproeier"
#define HA_LIGHT_STEEG_2      "light.steeg_bijkeukendeur"

#define HA_LIGHT_TUIN_1       "light.tuinwand_rechts_boven_2"
#define HA_LIGHT_TUIN_2       "light.signify_netherlands_b_v_lwg005"
#define HA_LIGHT_TUIN_3       "light.signify_netherlands_b_v_lwg005_2"
#define HA_LIGHT_TUIN_4       "light.tuinwand_rechts_onder"

// ============================================================
// KLIMAAT
// ============================================================

#define HA_SENSOR_WOONKAMER_TEMP \
    "sensor.temperatuur_woonkamer_temperatuur"

#define HA_CLIMATE_CENTRAAL \
    "climate.opentherm_gateway_otgw_otgw_thermostat"

#define HA_CLIMATE_TUINKANTOOR \
    "climate.vonroc_verwarming"

// ============================================================
// SONOS
// ============================================================

#define HA_SONOS_WOONKAMER \
    "media_player.woonkamer"

#define HA_SONOS_KANTOOR \
    "media_player.kantoor"

// ============================================================
// TV
// ============================================================

#define HA_TV_LG \
    "media_player.tv"

#define HA_TV_KPN \
    "media_player.kpn_tv"
