#include "scherm_ui.h"
#include <Arduino.h>

// ==========================================
// GLOBALE SCHERM OBJECTEN DEFINIËREN
// ==========================================
lv_obj_t * scr_home = nullptr;
lv_obj_t * scr_lights = nullptr;
lv_obj_t * scr_climate_overview = nullptr;
lv_obj_t * scr_climate_detail = nullptr;
lv_obj_t * scr_music = nullptr;

// Globale UI label pointers voor Home Assistant data
lv_obj_t * lbl_temp_home = nullptr;
lv_obj_t * lbl_weather = nullptr;

// ==========================================
// UI INITIALISATIE
// ==========================================
void setup_atag_style_ui() {
    // 1. Schermen direct en robuust aanmaken
    scr_home = lv_obj_create(NULL);
    scr_lights = lv_obj_create(NULL);
    scr_climate_overview = lv_obj_create(NULL);
    scr_climate_detail = lv_obj_create(NULL);
    scr_music = lv_obj_create(NULL);

    // 2. Bouw alle schermen op (elementen toevoegen)
    build_home_screen(scr_home);
    build_lights_screen(scr_lights);
    build_climate_overview(scr_climate_overview);
    build_climate_detail(scr_climate_detail);
    build_music_screen(scr_music);


    // 3. Start op het homescreen
    lv_scr_load(scr_home);
}

// ==========================================
// HOME ASSISTANT DATA SETTERS
// ==========================================
void ui_set_indoor_temp(int deg) {
    if (lbl_temp_home) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%d °C", deg);
        lv_label_set_text(lbl_temp_home, buf);
    }
}

void ui_set_outdoor_temp(int deg) {
    if (lbl_weather) {
        char buf[16];
        snprintf(buf, sizeof(buf), "%d °C", deg);
        lv_label_set_text(lbl_weather, buf);
    }
}

void ui_update_tile_state(int idx, const char* state) {
    // Logica voor tile status update
}

void ui_update_tile_value(int idx, const char* val) {
    // Logica voor tile waarde update
}

void ui_update_thermostat(ThermoState *s) {
    // Logica voor thermostaat update
}

void ui_set_ha_connected(bool connected) {
    Serial.printf("HA Connection status: %s\n", connected ? "Connected" : "Disconnected");
}

void ui_set_wifi_connected(bool connected) {
    Serial.printf("WiFi Connection status: %s\n", connected ? "Connected" : "Disconnected");
}

void ui_set_fan_state(bool on) {
    Serial.printf("Fan state: %s\n", on ? "ON" : "OFF");
}