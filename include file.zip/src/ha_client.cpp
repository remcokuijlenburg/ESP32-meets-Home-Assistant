#include "ha_client.h"

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

#include "secrets.h"
#include "ha_entities.h"
#include "scherm_ui.h"

// ============================================================
// INTERNE HULPFUNCTIES
// ============================================================

static String ha_get_state(const char* entity_id)
{
    HTTPClient http;

    String url =
        "http://" + String(HA_URL) +
        ":" + String(HA_PORT) +
        "/api/states/" + String(entity_id);

    http.begin(url);

    http.addHeader(
        "Authorization",
        "Bearer " + String(HA_TOKEN)
    );

    int httpCode = http.GET();

    if (httpCode != 200) {

        Serial.print("[HA] HTTP fout voor ");
        Serial.print(entity_id);
        Serial.print(": ");
        Serial.println(httpCode);

        http.end();

        return "";
    }

    String payload = http.getString();

    http.end();

    JsonDocument doc;

    DeserializationError err =
        deserializeJson(doc, payload);

    if (err) {

        Serial.print("[HA] JSON parse fout voor ");
        Serial.println(entity_id);

        return "";
    }

    return doc["state"].as<String>();
}

// ------------------------------------------------------------

static float ha_get_climate_target(const char* entity_id)
{
    HTTPClient http;

    String url =
        "http://" + String(HA_URL) +
        ":" + String(HA_PORT) +
        "/api/states/" + String(entity_id);

    http.begin(url);

    http.addHeader(
        "Authorization",
        "Bearer " + String(HA_TOKEN)
    );

    int httpCode = http.GET();

    if (httpCode != 200) {

        Serial.print("[HA] Climate HTTP fout: ");
        Serial.println(httpCode);

        http.end();

        return 20.0f;
    }

    String payload = http.getString();

    http.end();

    JsonDocument doc;

    DeserializationError err =
        deserializeJson(doc, payload);

    if (err) {

        Serial.println("[HA] Climate JSON parse fout");

        return 20.0f;
    }

    float target =
        doc["attributes"]["temperature"]
            .as<float>();

    return target;
}

// ============================================================
// VERLICHTING
// ============================================================

static void sync_lights()
{
    bool woonkamer_on =
        ha_get_state(HA_LIGHT_WOONKAMER_1) == "on" ||
        ha_get_state(HA_LIGHT_WOONKAMER_2) == "on";

    ui_set_light_state(
        "Woonkamer",
        woonkamer_on
    );

    bool hal_on =
        ha_get_state(HA_LIGHT_HAL_1) == "on" ||
        ha_get_state(HA_LIGHT_HAL_2) == "on";

    ui_set_light_state(
        "Hal",
        hal_on
    );
}

// ============================================================
// KLIMAAT
// ============================================================

static void sync_climate()
{
    // --------------------------------------------------------
    // Actuele temperatuur uit losse sensor
    // --------------------------------------------------------

    String temp_str =
        ha_get_state(
            HA_SENSOR_WOONKAMER_TEMP
        );

    Serial.print("[HA] Woonkamer sensor raw: ");
    Serial.println(temp_str);

    // Home Assistant kan soms "21,7" teruggeven

    temp_str.replace(",", ".");

    float current_temp =
        temp_str.toFloat();

    Serial.print("[HA] Parsed current temp: ");
    Serial.println(current_temp);

    // --------------------------------------------------------
    // Doeltemperatuur uit climate entity
    // --------------------------------------------------------

    float target_temp =
        ha_get_climate_target(
            HA_CLIMATE_CENTRAAL
        );

    Serial.print("[HA] Target temp: ");
    Serial.println(target_temp);

    // --------------------------------------------------------
    // Dummy verwarmingslogica
    // Later vervangen door echte hvac_action
    // --------------------------------------------------------

    bool heating =
        target_temp > current_temp;

    // --------------------------------------------------------
    // UI bijwerken
    // --------------------------------------------------------

    ui_set_climate_state(
        "Woonkamer",
        current_temp,
        target_temp,
        heating
    );
}

// ============================================================
// MUZIEK
// ============================================================

static void sync_music()
{
    bool playing =
        ha_get_state(
            HA_SONOS_WOONKAMER
        ) == "playing";

    ui_set_music_state(
        "Woonkamer Sonos",
        playing
    );
}

// ============================================================
// PUBLIEKE API
// ============================================================

void ha_init()
{
    Serial.println("[HA] Client initialized");
}

// ------------------------------------------------------------

void ha_loop()
{
    static uint32_t last_poll = 0;

    uint32_t now = millis();

    // Elke 5 seconden pollen

    if (now - last_poll < 5000) {

        return;
    }

    last_poll = now;

    // Alleen pollen als WiFi verbonden is

    if (WiFi.status() != WL_CONNECTED) {

        Serial.println("[HA] Geen WiFi verbinding");

        return;
    }

    Serial.println("[HA] Polling states...");

    sync_lights();

    sync_climate();

    sync_music();
}