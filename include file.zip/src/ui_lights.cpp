#include <lvgl.h>
#include <stdint.h>
#include <string.h>
#include "scherm_ui.h"

// ============================================================
// DATASTRUCTUUR
// ============================================================

struct LightItem {
    const char* name;
    bool is_on;

    // UI referenties
    lv_obj_t* tile;
    lv_obj_t* lbl_name;
};

// ============================================================
// DUMMY DATA
// ============================================================

#define NUM_LIGHTS 13

static LightItem lights[NUM_LIGHTS] = {
    {"Woonkamer",   true,  nullptr, nullptr},
    {"Keuken",      false, nullptr, nullptr},
    {"Hal",         false, nullptr, nullptr},
    {"Bijkeuken",   true,  nullptr, nullptr},
    {"Tuinkantoor", false, nullptr, nullptr},
    {"Schuur",      true,  nullptr, nullptr},
    {"Boaz",        false, nullptr, nullptr},
    {"Kai",         false, nullptr, nullptr},
    {"Badkamer",    false, nullptr, nullptr},
    {"Overloop",    false, nullptr, nullptr},
    {"Zolder",      true,  nullptr, nullptr},
    {"Tuin",        false, nullptr, nullptr},
    {"Steeg",       false, nullptr, nullptr}
};

// ============================================================
// KLEUREN
// ============================================================

static const lv_color_t COLOR_ON  = lv_color_hex(0x0099D8);
static const lv_color_t COLOR_OFF = lv_color_hex(0x222222);

// ============================================================
// TEGEL BIJWERKEN
// ============================================================

static void update_light_tile(int idx)
{
    LightItem& item = lights[idx];

    if (item.tile == nullptr) {
        return;
    }

    lv_obj_set_style_bg_color(
        item.tile,
        item.is_on ? COLOR_ON : COLOR_OFF,
        0
    );

    // Toekomstige uitbreidingen kunnen hier komen:
    // - icoon veranderen
    // - aantal actieve lampen tonen
    // - animatie toevoegen
}

// ============================================================
// PUBLIEKE UPDATEFUNCTIE (VOORBEREIDING HA)
// ============================================================

void ui_set_light_state(const char* room_name, bool state)
{
    for (int i = 0; i < NUM_LIGHTS; i++) {

        if (strcmp(lights[i].name, room_name) == 0) {

            lights[i].is_on = state;

            update_light_tile(i);

            break;
        }
    }
}

// ============================================================
// TOGGLE CALLBACK
// ============================================================

static void light_btn_event_cb(lv_event_t * e)
{
    int idx =
        (int)(uintptr_t)lv_event_get_user_data(e);

    lights[idx].is_on = !lights[idx].is_on;

    update_light_tile(idx);
}

// ============================================================
// TERUGKNOP
// ============================================================

static void back_btn_event_cb(lv_event_t * e)
{
    if (scr_home != NULL) {
        lv_scr_load(scr_home);
    }
}

// ============================================================
// SCHERM OPBOUW
// ============================================================

void build_lights_screen(lv_obj_t * parent)
{
    // --------------------------------------------------------
    // HOOFDCONTAINER
    // --------------------------------------------------------

    lv_obj_t * cont = lv_obj_create(parent);

    lv_obj_set_size(cont, 480, 480);
    lv_obj_align(cont, LV_ALIGN_CENTER, 0, 0);

    lv_obj_set_style_bg_color(
        cont,
        lv_color_hex(0x000000),
        0
    );

    lv_obj_set_style_border_width(cont, 0, 0);

    // --------------------------------------------------------
    // TITEL
    // --------------------------------------------------------

    lv_obj_t * lbl_title = lv_label_create(cont);

    lv_label_set_text(lbl_title, "Verlichting");

    lv_obj_set_style_text_font(
        lbl_title,
        &lv_font_montserrat_20,
        0
    );

    lv_obj_set_style_text_color(
        lbl_title,
        lv_color_hex(0xFFFFFF),
        0
    );

    lv_obj_align(
        lbl_title,
        LV_ALIGN_TOP_MID,
        0,
        15
    );

    // --------------------------------------------------------
    // TERUGKNOP
    // --------------------------------------------------------

    lv_obj_t * btn_back = lv_btn_create(cont);

    lv_obj_set_size(btn_back, 90, 40);

    lv_obj_align(
        btn_back,
        LV_ALIGN_TOP_LEFT,
        10,
        10
    );

    lv_obj_set_style_bg_color(
        btn_back,
        lv_color_hex(0x333333),
        0
    );

    lv_obj_add_event_cb(
        btn_back,
        back_btn_event_cb,
        LV_EVENT_CLICKED,
        NULL
    );

    lv_obj_t * lbl_back = lv_label_create(btn_back);

    lv_label_set_text(
        lbl_back,
        LV_SYMBOL_LEFT " Terug"
    );

    lv_obj_center(lbl_back);

    // --------------------------------------------------------
    // GRID CONTAINER
    // --------------------------------------------------------

    lv_obj_t * grid_cont = lv_obj_create(cont);

    lv_obj_set_size(grid_cont, 460, 400);

    lv_obj_align(
        grid_cont,
        LV_ALIGN_BOTTOM_MID,
        0,
        -5
    );

    lv_obj_set_style_bg_color(
        grid_cont,
        lv_color_hex(0x000000),
        0
    );

    lv_obj_set_style_border_width(grid_cont, 0, 0);

    lv_obj_set_style_pad_all(grid_cont, 0, 0);

    lv_obj_set_flex_flow(
        grid_cont,
        LV_FLEX_FLOW_ROW_WRAP
    );

    lv_obj_set_style_pad_gap(grid_cont, 8, 8);

    // --------------------------------------------------------
    // TEGELS GENEREREN
    // --------------------------------------------------------

    for (int i = 0; i < NUM_LIGHTS; i++) {

        // Tegel

        lv_obj_t * tile = lv_btn_create(grid_cont);

        lv_obj_set_size(tile, 106, 75);

        lv_obj_set_style_radius(tile, 10, 0);

        // UI referenties opslaan

        lights[i].tile = tile;

        // Event koppelen

        lv_obj_add_event_cb(
            tile,
            light_btn_event_cb,
            LV_EVENT_CLICKED,
            (void*)(uintptr_t)i
        );

        // Label

        lv_obj_t * lbl_name = lv_label_create(tile);

        lv_label_set_text(
            lbl_name,
            lights[i].name
        );

        lv_obj_set_style_text_font(
            lbl_name,
            &lv_font_montserrat_14,
            0
        );

        lv_obj_set_style_text_color(
            lbl_name,
            lv_color_hex(0xFFFFFF),
            0
        );

        lv_obj_center(lbl_name);

        lights[i].lbl_name = lbl_name;

        // Initiële status toepassen

        update_light_tile(i);
    }
}