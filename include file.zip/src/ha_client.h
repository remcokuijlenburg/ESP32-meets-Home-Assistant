#pragma once

void ha_init();
void ha_loop();