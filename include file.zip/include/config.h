#pragma once

// config.h — Tessera panel configuratie (Home Assistant entiteiten & tegels)
// Geen secrets hierin — die staan in secrets.h (setup_wizard.py)

// Netwerknaam van dit paneel (mDNS: <naam>.local), gebruikt voor OTA.
#define OTA_HOSTNAME "tessera"

// Header temperaturen (alleen-lezen)
// Indoor: leest current_temperature van de OpenTherm Gateway thermostaat
// Outdoor: leest temperature attribuut van weather.thuis
#define ENTITY_INDOOR_TEMP  "climate.opentherm_gateway_otgw_otgw_thermostat"
#define ENTITY_OUTDOOR_TEMP "weather.thuis"
// Geen fan-entiteiten aanwezig in deze HA-installatie — regel hieronder kan
// weg of ongebruikt blijven als je geen thermostaat-fan hebt.
#define ENTITY_THERMO_FAN "fan.none"

// Display
#define IDLE_DIM_MS   60000
#define BRIGHT_FULL   255
#define BRIGHT_DIM    40

// Backlight GPIO
#define PIN_BACKLIGHT 38

// GT911 touch pins (Guition ESP32-S3-4848S040 defaults)
#define PIN_TOUCH_SDA  19
#define PIN_TOUCH_SCL  45
#define PIN_TOUCH_INT  -1
#define PIN_TOUCH_RST  -1

// Icon catalogus (compleet — alleen deze ICON_* namen zijn beschikbaar)
#define ICON_LIGHTBULB     "\U000F0335"  // lightbulb
#define ICON_FAN           "\U000F1797"  // ceiling-fan
#define ICON_BED           "\U000F02E3"  // bed
#define ICON_CEILING_LIGHT "\U000F0769"  // ceiling-light
#define ICON_SOFA          "\U000F04B9"  // sofa
#define ICON_COACH_LAMP    "\U000F1020"  // coach-lamp (outdoor)
#define ICON_FAN_LIGHT     "\U000F1798"  // ceiling-fan-light
#define ICON_HOME_TEMP     "\U000F0F55"  // home-thermometer-outline (indoor)
#define ICON_WEATHER       "\U000F0595"  // weather-partly-cloudy (outdoor)
#define ICON_THERMOSTAT    "\U000F0393"  // thermostat (climate tile)

struct Tessera {
  const char* label;
  const char* entity_id;
  uint8_t page;
  float   on_pct;
  const char* icon;
  uint16_t on_kelvin;
};

// Tegels — afkomstig uit je "woonkamer bij zonsondergang" automatiseringen
static const Tessera MOSAIC[] = {
  // label     entity_id                  page  on_pct  icon              on_kelvin
  { "Remto",   "switch.smartplug_remto",    0,   0,     ICON_LIGHTBULB,   0 },
  { "K.O.O.",  "light.k_o_o",               0,   0,     ICON_LIGHTBULB,   3000 },
};

static const int MOSAIC_COUNT = sizeof(MOSAIC) / sizeof(MOSAIC[0]);
